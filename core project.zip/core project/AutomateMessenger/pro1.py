import pyautogui
import time
while True:
    pyautogui.typewrite('Sorry :(')
    time.sleep(5)
    pyautogui.press('enter')Sorry :(
        Sorry :(
        Sorry :(
        Sorry :()
    )
    )
    )